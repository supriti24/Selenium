package Assignment;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;

public class Assignment2 {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		ChromeOptions option = new ChromeOptions();
		option.addArguments("disable-notifications");
		 WebDriver driver = new ChromeDriver(option);
		 
		 driver.get("https://rahulshettyacademy.com/angularpractice/");
		 driver.manage().window().maximize();
		 
		 driver.findElement(By.name("name")).sendKeys("supriti");
		 driver.findElement(By.name("email")).sendKeys("supriti@gmail.com");
		 
		 driver.findElement(By.id("exampleInputPassword1")).sendKeys("123abc");
		 driver.findElement(By.id("exampleCheck1")).click();
		 
		 WebElement dropdown = driver.findElement(By.id("exampleFormControlSelect1"));
		 Select options = new Select(dropdown);
		 options.selectByVisibleText("Female");
		 
		 driver.findElement(By.id("inlineRadio2")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.name("bday")).sendKeys("24-11-1983");
		 driver.findElement(By.xpath("//input[@value='Submit']")).click();
		 System.out.println(driver.findElement(By.cssSelector(".alert-success")).getText());
		 
		 
		 
		 
	}

}
