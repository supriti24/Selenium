
public class CoreJavaBrushUp3 {



public static void main(String[] args) {

// TODO Auto-generated method stub



//string is an object //String literal

// if we have same string value with different variable name then it won't create a new object
// and would refer to the first variable's memory space 
// so in the below example 1 memory will be created to store "hello" and won't create a new string object s2.
	String s1 = "hello";
	String s2 = "hello";

// whereas if we have unique values for different variables then it will create different object with separate memory space
// so in the below example 1 memory will be created for s3 to store "hello" and another new string object for s4 to store "world".
	String s3 = "hello";
	String s4 = "world";
	
// Also if we are creating object using "new" keyword then no matter what the string is(same/different)
// for each object a new memory space will be allocated. 

	//new

	String s5 = new String("Welcome");

	String s6 = new String("Welcome");
	

String s = "Supriti Abhisht Pandey";

String[] splittedString = s.split(" ");

System.out.println(splittedString[0]);
System.out.println(splittedString[1]);
System.out.println(splittedString[2]);
System.out.println("***************************************");

System.out.println(s.length());
String[] splittedString2 = s.split("Abhisht");
System.out.println(splittedString2[1].trim());
StringBuilder reversed = new StringBuilder();

		for(int i =s.length()-1;i>=0;i--)		
			{
			
			//System.out.println(s.charAt(i));
			reversed.append(s.charAt(i));
			}
		System.out.println(reversed.toString());
	

	}

}















