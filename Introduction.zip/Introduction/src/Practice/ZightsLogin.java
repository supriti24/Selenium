package Practice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ZightsLogin {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		  WebDriver driver = new ChromeDriver();
	        
	        // Navigate to the Amazon home page
	        driver.get("https://zights.opteamix.com/login");
	        driver.manage().window().maximize();
	        
	        FileInputStream file = null;
	        XSSFWorkbook workbook = null;

	      //create a FileInputStream object to read the Excel file.
			 file = new FileInputStream(".//Book1.xlsx");
			//create a workbook object, representing the entire Excel file.
			 workbook = new XSSFWorkbook(file);
			//get a reference to the sheet named "Sheet1" using workbook.getSheet("Sheet1").
			XSSFSheet sheet = workbook.getSheet("Sheet1");
			// find the number of rows in the sheet.
			int Row_Count = sheet.getLastRowNum();
			// find the number of columns in the sheet.
			int Column_Count = sheet.getRow(0).getLastCellNum();
			//Reading Data from Cells
		
	for(int i=1;i<=Row_Count;i++) {
				
						XSSFRow current_row= sheet.getRow(i);

		                String cell_value1 = current_row.getCell(0).toString();	
						
						String cell_value2 = current_row.getCell(1).toString();	
						    			
		    			//Thread.sleep(2000);
		    	        // Login with credentials 
		    	        driver.findElement(By.xpath("//input[@name=\"userName\"]")).sendKeys(cell_value1);
		    	        driver.findElement(By.xpath("//input[@name=\"password\"]")).sendKeys(cell_value2);
		    	        
		    	        driver.findElement(By.xpath("//button[@type=\"submit\"]")).click();
		    	        Thread.sleep(5000);
		    			
		    			// System.out.print(cell_value1+" "+cell_value2);
				
			}
			       
	        // Click on Time Tracker
	        
	       // driver.findElement(By.xpath("//div[@class=\"opt-tabpills-body\"]/p[text()='Time Tracker']")).click();
	       driver.findElement(By.xpath("//div[@class=\"opt-tabpills-body\"]/p[text()=\"Time Tracker\"]")).click();
	     //   driver.findElement(By.xpath("//div[@class=\"opt-tabpills-body\"]/p")).click(); // css selector
	        //driver.findElement(By.xpath("//i[contains(@class,'opt-Icon opt-icon_timetracker opt-icon-large')]")).click(); // xpath
	       // Thread.sleep(2000);
	        
	        // Select a client
	        driver.findElement(By.xpath("//span[text()=\"Client\"]")).click();
	         Thread.sleep(2000);
			driver.findElement(By.xpath("//input[contains(@placeholder,\"Lookup\")][1]")).sendKeys("Maximus Inc");
			driver.findElement(By.xpath("//div[@class=\"scrolling menu\"]/div")).click();
			 Thread.sleep(2000);
			
			// Select a Project
			driver.findElement(By.xpath("//span[text()=\"Project\"]")).click();	
			 Thread.sleep(2000);
			driver.findElement(By.xpath("//div[@class='col-3 col-sm-3 col-md-3 col-lg-2 col-xl-3 p-1 ml-2']//input[@placeholder='Lookup']")).sendKeys("NCEB");
			driver.findElement(By.xpath("//div[contains(text(),'North Carolina Enrolment Broker (NCEB)')]")).click();
			 Thread.sleep(2000);
			
			// reading timesheet xls
				
			  FileInputStream file2 = null;
		        XSSFWorkbook workbook2 = null;

		      //create a FileInputStream object to read the Excel file.
				 file2 = new FileInputStream(".//Book2.xlsx");
				//create a workbook object, representing the entire Excel file.
				 workbook2 = new XSSFWorkbook(file2);
				//get a reference to the sheet named "Sheet1" using workbook.getSheet("Sheet1").
				XSSFSheet sheet2 = workbook2.getSheet("Sheet1");
				// find the number of rows in the sheet.
				int Row_Count2 = sheet2.getLastRowNum();
				// find the number of columns in the sheet.
				int Column_Count2 = sheet2.getRow(0).getLastCellNum();
			//	System.out.println("column count = " +Column_Count2);
			//	System.out.println("column count = " + Row_Count2);
				
	// Log time for 5 days 
		for(int i = 1; i<=Row_Count2;i++) {
						
			for (int j = 0; j < Column_Count2; j++) {		
				
	//driver.findElement(By.xpath("//div[@class=\"col-12 mt-2\"]["+i+"]/div[class=\"opt-multidata-container\"]/div[@class=\"opt-days-pills\"]["+(j+1)+"]")).click(); 
//				driver.findElement(By.xpath("//div[@class=\"opt-days-pills\"]["+(j+1)+"]")).click(); 
				driver.findElement(By.xpath("//div[@class='timetracker-entry-section w-100']/div[@class='col-12 mb-3']/div[1]/div["+(i+1)+"]/div[1]/div["+(j+1)+"]")).click(); 
				
				//Reading Data from Cells
				XSSFRow current_row2= sheet2.getRow(i); 
	            String day = current_row2.getCell(j).toString();  
	            System.out.println(day);		
	            		               
			    // Log hours for each day
	            driver.findElement(By.xpath("//input[@placeholder=\"Hours\"]")).sendKeys(day);
	            driver.findElement(By.xpath("//div[text()='Select Activity']")).click();
	            
	         //   driver.findElement(By.xpath("//div[@departmentactivityid= 722")).click();		
	            driver.findElement(By.xpath("//div[@role=\"listbox\"]/div[@departmentactivityid=\"708\"]")).click();
	            driver.findElement(By.xpath("//i[@class='fa fa-floppy-o']")).click();
			}
			
		}		
		    // Save the Timesheet
			//driver.findElement(By.xpath("//button[normalize-space()='Save']")).click();   
			//Thread.sleep(5000);
			 // Submit the Timesheet
		//	driver.findElement(By.xpath("//button[normalize-space()='Submit']")).click();
	   //    Thread.sleep(5000);  
			//driver.quit();



	}

}
