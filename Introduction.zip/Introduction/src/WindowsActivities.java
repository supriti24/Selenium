import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class WindowsActivities {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		// System.setProperty("webdriver.chrome.driver", "D:/Users/403893/Documents/Selenium/Browser_exe/chromedriver.exe");
		 WebDriver driver = new EdgeDriver();
		 driver.manage().window().maximize();
		 driver.get("http://www.google.com");
		 driver.navigate().to("http://www.rahulshettyacademy.com");
		 driver.navigate().back();
 
	// Sibling-Sibling 
		 driver.get("https://www.rahulshettyacademy.com/AutomationPractice/");
		 System.out.println(driver.findElement(By.xpath("//header/div/button[1]/following-sibling::button[1]")).getText());
    //  Child to Parent traverse	 
		 System.out.println(driver.findElement(By.xpath("//header/div/button[1]/parent::div/button[2]")).getText());
	
		 
		 
	
	}
}
