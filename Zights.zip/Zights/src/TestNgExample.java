import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.io.FileInputStream;
import java.io.IOException;

public class TestNgExample {

    WebDriver driver;

    @BeforeClass
    public void setUp() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
    }

    @Test
    public void loginAndSubmitTimesheet() throws InterruptedException, IOException {
        driver.get("https://zights-mms.maximusgccindia.com/login");

        FileInputStream file = new FileInputStream(".//Book1.xlsx");
        XSSFWorkbook workbook = new XSSFWorkbook(file);
        XSSFSheet sheet = workbook.getSheet("Sheet1");

        for (int i = 1; i <= sheet.getLastRowNum(); i++) {
            XSSFRow currentRow = sheet.getRow(i);
            String username = currentRow.getCell(0).toString();
            String password = currentRow.getCell(1).toString();

            driver.findElement(By.name("userName")).sendKeys(username);
            driver.findElement(By.name("password")).sendKeys(password);
            driver.findElement(By.tagName("button")).click();
            Thread.sleep(5000);

            driver.findElement(By.xpath("//div[contains(text(),'Time Tracker')]")).click();
            Thread.sleep(2000);

            // Select Client
            driver.findElement(By.xpath("//span[text()='Client']")).click();
            Thread.sleep(2000);
            driver.findElement(By.xpath("//span[contains(text(),'Lookup')]/parent::div/input")).sendKeys("Maximus Inc");
            driver.findElement(By.xpath("//div[contains(text(),'Maximus Inc')]")).click();
            Thread.sleep(2000);

            // Select Project
            driver.findElement(By.xpath("//span[text()='Project']")).click();
            Thread.sleep(2000);
            driver.findElement(By.xpath("//span[contains(text(),'Lookup')]/parent::div/input")).sendKeys("NCEB");
            driver.findElement(By.xpath("//div[contains(text(),'North Carolina Enrolment Broker (NCEB)')]")).click();
            Thread.sleep(2000);

            FileInputStream file2 = new FileInputStream(".//Book2.xlsx");
            XSSFWorkbook workbook2 = new XSSFWorkbook(file2);
            XSSFSheet sheet2 = workbook2.getSheet("Sheet1");

            for (int j = 1; j <= sheet2.getLastRowNum(); j++) {
                for (int k = 0; k < sheet2.getRow(0).getLastCellNum(); k++) {
                    String hours = sheet2.getRow(j).getCell(k).toString();

                    driver.findElement(By.xpath("//div[@class='timetracker-entry-section w-100']/div[@class='col-12 mb-3']/div[1]/div[" + (j + 1) + "]/div[" + (k + 1) + "]")).click();
                    Thread.sleep(1000);
                    driver.findElement(By.xpath("//input[@placeholder='Hours']")).sendKeys(hours);
                    driver.findElement(By.xpath("//div[text()='Select Activity']")).click();
                    driver.findElement(By.xpath("//div[@role='listbox']/div[@departmentactivityid='708']")).click();
                    driver.findElement(By.cssSelector("i.fa.fa-floppy-o")).click();
                }
            }

            workbook2.close();
        }

        workbook.close();
    }

    @AfterClass
    public void tearDown() {
        driver.quit();
    }
}
