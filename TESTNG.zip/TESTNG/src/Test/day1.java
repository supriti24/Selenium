package Test;

import org.openqa.selenium.Webdriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class day1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.setProperty("webdriver.chrome.driver","D:\\Users\\403893\\Temp\\chromedriver-win64\\chromedriver-win64");
		
		
		WebDriver driver = new ChromeDriver();
		
		driver
	}

}
