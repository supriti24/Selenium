import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class selintro {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// step to invoke CHROME driver
		 System.setProperty("webdriver.chrome.driver", "D:/Users/403893/Documents/Selenium/Browser_exe/chromedriver.exe");
		 WebDriver driver = new ChromeDriver();
		
		// step to invoke FIREFOX driver
//		 System.setProperty("webdriver.gecko.driver", "D:/Users/403893/Documents/Selenium/Browser_exe/geckodriver.exe");
//		 WebDriver driver = new FirefoxDriver();
		
		// step to invoke EDGE driver 
//		 System.setProperty("webdriver.edge.driver", "D:/Users/403893/Documents/Selenium/Browser_exe/msedgedriver.exe");
//		  WebDriver driver = new EdgeDriver();
		 
		// if not using above set property we can use selenium manager instead which will might have 2 - 3 sec  lag
		
		 driver.get("https://eb-qa.np-nc-eb.maximus.com/eb/");
		 System.out.println(driver.getTitle());
		 System.out.println(driver.getCurrentUrl());
		// driver.close(); // closes only the current window, 
		 driver.quit();//  closes all associated window , if my script opens multiple windows so we should use this
		 
		
		 
		 		 
	}

}
