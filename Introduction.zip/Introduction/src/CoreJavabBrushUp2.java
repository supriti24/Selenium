import java.util.ArrayList;

public class CoreJavabBrushUp2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayList<String> a = new ArrayList<String>();
		a.add("supriti"); a.add("pandey"); a.add("Goals For"); a.add("selenium certification");
		
		for(int i =0; i<a.size(); i++) // we use object.size() for arraylist whereas in array we used a.lenghth
		{
			System.out.println(a.get(i));	
		}
		
		for(String s : a) // enhanced for loop : array list o right side of colon
		{
			System.out.println(s);	
		}
		
		System.out.println(a.contains("selenium certification"));
	
		

	}

}
