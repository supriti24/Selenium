import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class Login2 {

    public static void main(String[] args) {
        WebDriver driver = new ChromeDriver();
        WebDriverWait wait = new WebDriverWait(driver, 10);

        try {
            driver.get("https://zights.opteamix.com/login");
            driver.manage().window().maximize();

            // Login with credentials 
            driver.findElement(By.name("userName")).sendKeys("spandey");
            driver.findElement(By.name("password")).sendKeys("Maxi@1023");

            // Wait for the login button to be clickable
            WebElement loginButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@type='submit']")));
            loginButton.click();

            // Other waits can be similarly incorporated throughout your script.

            // Click on Time Tracker
            WebElement timeTrackerTab = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='opt-tabpills-body']/p[text()='Time Tracker']")));
            timeTrackerTab.click();

            // Select a client
            WebElement clientDropdown = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Client']")));
            clientDropdown.click();

            // Other interactions can be similarly modified with WebDriverWait.

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            driver.quit();
        }
    }
}
