import java.util.Arrays;
import java.util.List;

public class CoreJAVAbrushup {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a = 5; String b = "supriti"; char c = 'S'; boolean d = true; double e = 5.88;
		
		// array delaration followed by initialisation and then printing
		int[] arr1 = new int[5]; // array delaration
	    // array initialisation
		arr1[0]=1; arr1[1]=2; arr1[2]=3; arr1[3]=4; arr1[4]=5;
		
		for(int i=0; i<arr1.length; i++)
		{ System.out.println(arr1[i]); }
	
		//direct  array initialization  and printing
		 int[] arr2 = {7,8,9,10,11};  
		
		for(int j=0; j<arr2.length; j++)
		{ System.out.println(arr2[j]); }

		// string array initialization and printing method 1
		
		String[] name1 = {"S1","S2","S3","S4","S5","S6"};
		String[] name2= {"S7","S8","S9","S10","S11","S12"};
		
		for(int k =0; k < name1.length; k++) {
			System.out.println(name1[k]);
		}
		
		// enhanced "for loop" for string array initialization
		
		for(String s : name2) {
			 System.out.println(s);
		}
//		
		List<String> name = Arrays.asList(name2);
		System.out.println(name.contains("S11"));
		
		
		
	}
}
