public class MethodsDemo {

		public static void main(String[] args) {
		// TODO Auto-generated method stub

		MethodsDemo d = new MethodsDemo(); // creating object to call method of the same class.
		MethodsDemo2 d1 = new MethodsDemo2(); // creating object to call method of class outside.
		
		String name = d.getData();		
		String name2 = getData2();
		String name3 = d1.getUserData();
		
		System.out.println(name);
		System.out.println(name2);
		System.out.println(name3);		
	
}
		public String getData()
		{ //	System.out.println ("hello");
			return "im in getData";
		}		
		public static String getData2()

	   {	//			System.out.println ("Hi");	
			return "im in getData2";	
	   }

}  

