/**
 * 
 */
/**
 * 
 */
module TESTNG {
	requires org.seleniumhq.selenium.chrome_driver;
}