package tests;

import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class e2e {

	public static void main(String[] args) throws InterruptedException {
	      
        ChromeOptions options = new ChromeOptions();
        
        //
      

        Map<String, Object> prefs=new HashMap<String,Object>();

        prefs.put("profile.default_content_setting_values.notifications", 1);

        //1-Allow, 2-Block, 0-default

        options.setExperimentalOption("prefs",prefs);

        WebDriver driver = new ChromeDriver(options);

        driver.get("http://www.spicejet.com");
        //
 //       options.addArguments("--disable-infobars", "--incognito", "--disable-notifications");
 
   //     WebDriver driver = new ChromeDriver(options);
 
 //       driver.get("http://spicejet.com"); //URL in the browser
 
 
        //click to open dropdown of Origin using parent-child relationship xpath
          driver.findElement(By.xpath("//div[@data-testid='to-testID-origin'] //input[@type='text']")).click();
 
        //selecting BLR city
        driver.findElement(By.xpath("//div[contains(text(),'BLR')]")).click();
 
        Thread.sleep(2000);
 
        //click to open dropdown of destination and then select chennai MAA
     //   driver.findElement(By.xpath("//div[@data-testid='to-testID-destination'] //input[@type='text']")).click();
        driver.findElement(By.xpath("//div[contains(text(),'MAA')]")).click();
    }

}
